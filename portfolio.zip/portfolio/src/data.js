module.exports = {
    "socials": [
        {
            "icon": "twitter",
            "url": "http://twitter/"
        },
        {
            "icon": "github-circled",
            "url": "http://github"
        },
        {
            "icon": "dribbble",
            "url": "http://dribbble"
        },
        {
            "icon": "skype",
            "url": "htttp://skype"
        },
        {
            "icon": "mail-alt",
            "url": "mailto: email"
        },
        {
            "icon": "linkedin-squared",
            "url": "https://www.linkedin.com/in/sheeerazahmed/"
        }
    ],
    "experiences": [
        {
            "__key": "04c84a86-58a7-488d-9710-65268059f794",
            "title": "Technical Support Analyst at Scotiabank",
            "timeline": "June 2017 - Present",
            "description": "Implemented Gamification for system",
            "responsibilities": [
                "Maintaining accurate problem logs (BITs and EDGE tickets): Keeping issues updated using the BITS/EDGE ticketing system and ensure customers are followed up with after problem has been resolved and raised JIRA tickets",
                "Provide support and troubleshoot with customers for system related issues and system access (resetting password/reconfiguring token device/java configuration/browser setup)",
                "Provide support with implementation of Scotiabank Software/Scanners along with troubleshooting ",
                "Assisted customers with Global Massive Payment Reporting (Electronic Fund Transfers, Wire Payments, Bill Payments, Stop Payments, Integrated Payments)",
                "Continuously achieving 100% CSAT for customer resolution"
            ]
        },
        {
            "__key": "4569d6bd-37d1-4262-acc1-e41f83eb509c",
            "title": "Technical Sales Representative at PC Financial",
            "timeline": "January 2016 - June 2017",
            "responsibilities": [
                "Provided second-tier technical support to sales representative in field (Resetting tablets, troubleshooting network problems)",
                "Configured and set up MAGTEK printer on field and tablets (Configured router network settings)",
                "Assisting in special projects as required ",
                "Meet sale targets and using available resources to meet SLA’s (Target of 20 prints a day minimum)",
                "Setup configure required hardware and support mobile devices: Record, track and escalate complex technical issues.\n",
                "Meet sale targets by working in a team environment with the sales representatives: providing exceptional service to all departments using available resources while meeting set SLA’s"
            ]
        },
        {
            "__key": "d60a6370-ba45-40dc-90bb-5f4e0ad8c517",
            "title": "IT Intern",
            "timeline": "January 2015 - February 2016",
            "description": "",
            "responsibilities": [
                "Diagnosing and repairing customers’ computer in a timely manner: installation of computer hardware and software: recommended use of “Team Viewer” for providing support remotely and procured business license to implement the solution\n",
                "Provide technical support of LAN, desktop, server, and peripheral equipment: Create/update/resolve incidents or requests via BMC Remedy Ticketing System\n",
                "Responsible for network design and installation/maintenance of existing IT services: Identify, troubleshoot, resolve hardware, software, and network related problems\n"
            ]
        }
    ],
    "name": "Sheeraz Ahmed",
    "header": "Hi, I'm Sheeraz Ahmed",
    "cta": {
        "label": "Get my resume",
        "url": "https://www.linkedin.com/in/sheeerazahmed/"
    },
    "testimonials": [],
    "title": "Sheeraz Ahmed",
    "projects": [
        {
            "__key": "651b0017-197b-45d8-9deb-6caf17ce3f05",
            "name": "The Refreshment Application",
            "description": "A User-Interface design with the usage of multiple usability design principles giving the user freedom and control of the application.  ",
            "tags": [
                "User Interface",
                "Usability",
                "Wireframe",
                "Prototypes (High + Low Fidelity)"
            ],
            "alt": "Refreshment Application Screenshot",
            "img": "proto4.png",
            "url": "//"
        },
        {
            "__key": "e50526f1-c495-4952-846b-7a3277bd47f7",
            "name": "Math Equation Solver Application",
            "description": "MAT135 is an application designed to help math students by providing solutions and instant feedback",
            "tags": [
                "Equations Solver"
            ],
            "img": "mat135.png",
            "url": "https://projects.invisionapp.com/share/46ATJI0D9#/screens/223092825",
            "alt": "MAT135 Screenshot"
        },
        {
            "__key": "36d203d2-891a-42ce-b68f-fa5e0b039750",
            "name": "Game Development Project",
            "description": "This is a game that was created on the software Unity, the artwork and code was self-developed.",
            "tags": [
                "Gaming"
            ],
            "alt": "Battleship Screenshot",
            "img": "battleship.png",
            "url": "//"
        },
        {
            "__key": "62c44249-2f24-44b8-a0d4-f6915003e8d2",
            "name": "Other Artwork",
            "description": "This is other design projects I have worked on which have been created through Adobe Illustrator and Photoshop",
            "tags": [],
            "alt": "Artwork",
            "img": "artwork.png",
            "url": "//"
        }
    ],
    "email": "sheeraz.ahmd13@gmail.com",
    "description": "Having previous IT experience with on-site workstation deployment and technical support, as well as managing a ticketing help-desk, I am looking to broaden my skill set in the IT and User Interface Designing field. I recently graduated with a BA in Communication, Culture & Information Technology and a certificate in Digital Communications. I'm looking to put my critical thinking and technical skills to use in a client/customer focused technical environment. ",
    "footerTitle": "Technical Support Analyst"
}